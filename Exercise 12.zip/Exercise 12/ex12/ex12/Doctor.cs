﻿using System;
namespace ex12
{
    public class Doctor
    {
        private string fullName;
        private string registryNumber;
        private string specialty;

        public Doctor(string fullName, string registryNumber, string specialty)
        {
            this.fullName = fullName;
            this.registryNumber = registryNumber;
            this.specialty = specialty;
        }
        public string getName()
        {
            return fullName;
        }
        public string getRegistryNumber()
        {
            return registryNumber;
        }
        public string getSpecialty()
        {
            return specialty;
        }
        public void setName(string fullName)
        {
            this.fullName = fullName;
        }
        public Boolean equals(Doctor doctor)
        {
            if (this.registryNumber == doctor.registryNumber)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }
        public string toString()
        {
            return "Dr. "+fullName+", Specialty: "+specialty ;
        }

    }
}

