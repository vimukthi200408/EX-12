﻿using System;
namespace ex12
{
    public class DoctorRegistry
    {
        public DoctorRegistry()
        {
        }
    }
}

