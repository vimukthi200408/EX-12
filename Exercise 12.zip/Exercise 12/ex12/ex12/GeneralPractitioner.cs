﻿using System;
namespace ex12
{
    public class GeneralPractitioner : Doctor
    {
        private string practiceName;
        private string address;

        public GeneralPractitioner(string fullName, string registryNumber, string specialty, string practiceName, string address) : base(fullName, registryNumber, specialty)
        {
            this.practiceName = practiceName;
            this.address = address;
        }
        public string toString()
        {
            return "Dr. " + getName() + ", Specialty: " + getSpecialty + ", Practice: " + practiceName;
        }
    }
}

