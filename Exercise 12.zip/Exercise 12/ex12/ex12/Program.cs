﻿namespace ex12
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine("the");
            Console.ReadKey();
            
        }
    }
}